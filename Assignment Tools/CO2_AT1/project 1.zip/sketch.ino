/*
  Automotive ABS System
  Embedded C Simulation using Arduino UNO
  External Interrupt + Real-Time Simulation
*/

#define BRAKE_PIN 2
#define LED_PIN 13

volatile bool brakePressed = false;

int wheelSpeed = 80;
const int threshold = 20;

void brakeInterrupt()
{
  brakePressed = true;
}

void setup()
{
  pinMode(BRAKE_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);

  Serial.begin(9600);

  attachInterrupt(
    digitalPinToInterrupt(BRAKE_PIN),
    brakeInterrupt,
    FALLING);

  Serial.println("========================================");
  Serial.println(" AUTOMOTIVE ABS SYSTEM SIMULATION");
  Serial.println("========================================");
  Serial.println("System Started...");
  Serial.println();
}

void loop()
{
  Serial.print("Wheel Speed : ");
  Serial.print(wheelSpeed);
  Serial.println(" km/h");

  if (brakePressed)
  {
    Serial.println("--------------------------------");
    Serial.println("Brake Pedal Pressed");
    Serial.println("--------------------------------");

    if (wheelSpeed <= threshold)
    {
      digitalWrite(LED_PIN, HIGH);

      Serial.println("ABS ACTIVATED");
      Serial.println("Wheel Lock Detected");
      Serial.println("Brake Pressure Released");
      Serial.println("ABS LED ON");

      wheelSpeed += 15;

      delay(1000);

      digitalWrite(LED_PIN, LOW);

      Serial.println("Wheel Speed Restored");
      Serial.println("ABS DEACTIVATED");
      Serial.println("ABS LED OFF");
    }
    else
    {
      Serial.println("Wheel Speed Normal");
      Serial.println("ABS NOT REQUIRED");
    }

    brakePressed = false;

    Serial.println("--------------------------------");
  }

  wheelSpeed -= 5;

  if (wheelSpeed < 0)
  {
    Serial.println();
    Serial.println("Vehicle Restarted");
    Serial.println();

    wheelSpeed = 80;
  }

  delay(1000);
}